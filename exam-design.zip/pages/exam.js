import React from "react";
import Exam from "../components/Exam";

const ExamPage = () => <Exam />;
export default ExamPage;
