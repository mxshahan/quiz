import React from "react";
import PostExam from "../components/PostExam";

const PostExamPage = () => <PostExam />;

export default PostExamPage;
