import React from "react";
import PreExam from "../components/PreExam";
const PreExamPage = () => <PreExam />

export default PreExamPage;
