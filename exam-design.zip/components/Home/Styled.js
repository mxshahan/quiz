import "styled-components";
import styled from "styled-components";

export const HomeWrapper = styled.div`
  height: 100vh;
  background-color: #031e40;
`;
